import static org.junit.Assert.*;   // herramientas JUnit
import org.junit.Test;             // anotacion @Test

public class TowerTest
{
    // ---------------------------------------------------------
    // Create tower
    // ---------------------------------------------------------

    @Test
    public void shouldCreateTowerOkTrue()
    {
        Tower t = new Tower(10, 20);
        assertTrue(t.ok());
    }

    // ---------------------------------------------------------
    // Manage cup (basico)
    // ---------------------------------------------------------

    @Test
    public void shouldPushCup()
    {
        Tower t = new Tower(10, 20);

        t.pushCup(5);

        assertTrue(t.ok());
        assertEquals(5, t.height()); // cup 5 -> 5 cm (basico)
    }

    @Test
    public void shouldPopCup()
    {
        Tower t = new Tower(10, 20);

        t.pushCup(5);
        t.pushCup(7);

        t.popCup();

        assertTrue(t.ok());

        // Después de sacar la 7, queda solo la 5 (altura 5)
        assertEquals(5, t.height());
    }

    @Test
    public void shouldRemoveCup()
    {
        Tower t = new Tower(10, 20);

        t.pushCup(5);
        t.pushCup(7);

        t.removeCup(5);

        assertTrue(t.ok());

        // Queda solo la 7
        assertEquals(7, t.height());
    }

    @Test
    public void shouldFailPopCupWhenEmpty()
    {
        Tower t = new Tower(10, 20);

        t.popCup();

        assertFalse(t.ok());
    }

    @Test
    public void shouldFailRemoveCupWhenNotFound()
    {
        Tower t = new Tower(10, 20);
        t.pushCup(5);

        t.removeCup(7);

        assertFalse(t.ok());
    }

    // ---------------------------------------------------------
    // Manage lid (nuevo)
    // ---------------------------------------------------------

    @Test
    public void shouldPushLid()
    {
        Tower t = new Tower(10, 20);

        t.pushLid(5);

        assertTrue(t.ok());
        assertEquals(1, t.height()); // lid = 1 cm
    }

    @Test
    public void shouldPopLid()
    {
        Tower t = new Tower(10, 20);

        t.pushLid(5);
        t.popLid();

        assertTrue(t.ok());
        assertEquals(0, t.height());
    }

    @Test
    public void shouldFailPopLidWhenTopIsNotLid()
    {
        Tower t = new Tower(10, 20);

        t.pushCup(5);
        t.popLid();

        assertFalse(t.ok());
    }

    @Test
    public void shouldRemoveLid()
    {
        Tower t = new Tower(10, 20);

        t.pushLid(5);
        t.pushLid(7);

        t.removeLid(5);

        assertTrue(t.ok());
        assertEquals(1, t.height()); // queda solo lid 7 => 1
    }

    @Test
    public void shouldFailRemoveLidWhenNotFound()
    {
        Tower t = new Tower(10, 20);

        t.pushLid(5);
        t.removeLid(7);

        assertFalse(t.ok());
    }

    // ---------------------------------------------------------
    // Regla: cup + lid se mueven juntas (nuevo)
    // ---------------------------------------------------------

    @Test
    public void shouldPopCupRemoveBothWhenCupIsLidded()
    {
        Tower t = new Tower(10, 20);

        t.pushCup(5);
        t.pushLid(5);     // tapa justo encima de cup 5

        t.popCup();       // al sacar cup de cima, se van ambos

        assertTrue(t.ok());
        assertEquals(0, t.height());
    }

    @Test
    public void shouldRemoveCupRemoveItsLidToo()
    {
        Tower t = new Tower(10, 20);

        t.pushCup(5);
        t.pushLid(5);
        t.pushCup(7);

        t.removeCup(5);   // elimina cup 5 y su lid 5

        assertTrue(t.ok());
        assertEquals(7, t.height()); // queda solo cup 7 => 7
    }

    // ---------------------------------------------------------
    // Consult information (nuevo)
    // ---------------------------------------------------------

    @Test
    public void shouldReturnLidedCups()
    {
        Tower t = new Tower(10, 50);

        t.pushCup(5);
        t.pushLid(5);
        t.pushCup(7);
        t.pushLid(7);
        t.pushCup(3);

        int[] lided = t.lidedCups();

        // deben estar 5 y 7 (no importa el orden exacto)
        assertEquals(2, lided.length);
        assertTrue(contains(lided, 5));
        assertTrue(contains(lided, 7));
    }

    @Test
    public void shouldReturnStackingItems()
    {
        Tower t = new Tower(10, 50);

        t.pushCup(5);
        t.pushLid(5);
        t.pushCup(3);

        String[][] info = t.stackingItems();

        assertEquals(3, info.length);

        // Debe haber exactamente 2 columnas: tipo y numero
        assertEquals(2, info[0].length);
        assertEquals(2, info[1].length);
        assertEquals(2, info[2].length);

        // Verifica contenido basico esperado (orden real apilado):
        // cup 5, lid 5, cup 3
        assertEquals("cup", info[0][0]);
        assertEquals("5",   info[0][1]);

        assertEquals("lid", info[1][0]);
        assertEquals("5",   info[1][1]);

        assertEquals("cup", info[2][0]);
        assertEquals("3",   info[2][1]);
    }

    // ---------------------------------------------------------
    // Reorganize tower (nuevo)
    // ---------------------------------------------------------

    @Test
    public void shouldReverseTower()
    {
        Tower t = new Tower(10, 50);

        t.pushCup(5);
        t.pushLid(5);
        t.pushCup(3);

        t.reverseTower();

        assertTrue(t.ok());

        String[][] info = t.stackingItems();

        // inverso basico pero manteniendo pareja lid encima de cup si existe
        // Al invertir: cup3, cup5, lid5 (y luego normalize => cup5, lid5 juntos)
        // Resultado esperado final: cup3, cup5, lid5
        assertEquals("cup", info[0][0]);
        assertEquals("3",   info[0][1]);

        assertEquals("cup", info[1][0]);
        assertEquals("5",   info[1][1]);

        assertEquals("lid", info[2][0]);
        assertEquals("5",   info[2][1]);
    }

    @Test
    public void shouldOrderTowerDescending()
    {
        Tower t = new Tower(10, 50);

        t.pushCup(3);
        t.pushCup(7);
        t.pushLid(7);
        t.pushCup(5);

        t.orderTower();

        assertTrue(t.ok());

        String[][] info = t.stackingItems();

        // Orden mayor a menor por numero:
        // 7 (cup, lid), 5 (cup), 3 (cup)
        assertEquals("cup", info[0][0]);  assertEquals("7", info[0][1]);
        assertEquals("lid", info[1][0]);  assertEquals("7", info[1][1]);
        assertEquals("cup", info[2][0]);  assertEquals("5", info[2][1]);
        assertEquals("cup", info[3][0]);  assertEquals("3", info[3][1]);
    }

    // ---------------------------------------------------------
    // Visibility + Exit (nuevo)
    // ---------------------------------------------------------

    @Test
    public void shouldMakeVisibleAndInvisible()
    {
        Tower t = new Tower(10, 20);

        t.makeVisible();
        assertTrue(t.ok());

        t.makeInvisible();
        assertTrue(t.ok());
    }

    @Test
    public void shouldExitClearTower()
    {
        Tower t = new Tower(10, 50);

        t.pushCup(5);
        t.pushLid(5);

        t.exit();

        assertTrue(t.ok());
        assertEquals(0, t.height());
        assertEquals(0, t.stackingItems().length);
    }

    // ---------------------------------------------------------
    // Helper para asserts
    // ---------------------------------------------------------

    private boolean contains(int[] arr, int x)
    {
        for (int v : arr)
        {
            if (v == x) return true;
        }
        return false;
    }
}