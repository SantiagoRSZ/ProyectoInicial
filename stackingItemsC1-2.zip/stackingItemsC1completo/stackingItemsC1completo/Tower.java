import java.util.ArrayList;            // Para usar ArrayList
import java.util.Collections;          // Para ordenar / invertir
import java.util.Comparator;           // Para el sort
import javax.swing.JOptionPane;        // Para mensajes si esta visible

/**
 * Tower: torre apilada de cups y lids.
 * - types[k]  = "cup" o "lid"
 * - nums[k]   = numero i del elemento
 * Ambos arrays representan el mismo elemento en el mismo indice.
 */
public class Tower
{
    private int width;                         // ancho
    private int maxHeight;                     // alto maximo
    private boolean visible;                   // visible / invisible
    private boolean ok;                        // estado ultima operacion

    private ArrayList<String> types;           // tipo del elemento ("cup"/"lid")
    private ArrayList<Integer> nums;           // numero del elemento (i)

    // -------------------------
    // Constructor: create tower
    // -------------------------
    public Tower(int width, int maxHeight)
    {
        this.width = width;                    // guarda ancho
        this.maxHeight = maxHeight;            // guarda alto
        this.visible = false;                  // inicia invisible
        this.ok = true;                        // inicia ok

        this.types = new ArrayList<String>();  // lista vacia tipos
        this.nums  = new ArrayList<Integer>(); // lista vacia numeros
    }
    
    
    //Constructor: Create Tower With Number of Cups
    public Tower(int cups)
    {
        this.width     = 2 * cups - 1;
        this.maxHeight = cups * (cups + 1) / 2;
        this.visible   = false;
        this.ok        = true;
        this.types     = new ArrayList<String>();
        this.nums      = new ArrayList<Integer>();

        for (int i = cups; i >= 1; i--)
        {
            types.add("cup");
            nums.add(i);
        }
    }

    
    // =========================
    // Helpers privados
    // =========================

    // Muestra mensaje solo si visible
    private void showIfVisible(String msg)
    {
        if (visible)
        {
            JOptionPane.showMessageDialog(null, msg);
        }
    }

    // Altura de una cup i (basico): i cm
    private int cupHeight(int i)
    {
        return i;
    }

    // Altura de una lid: 1 cm
    private int lidHeight()
    {
        return 1;
    }

    // Altura total actual
    private int currentHeight()
    {
        int total = 0;

        for (int k = 0; k < types.size(); k++)
        {
            if (types.get(k).equals("cup"))
            {
                total += cupHeight(nums.get(k));
            }
            else
            {
                total += lidHeight();
            }
        }
        return total;
    }

    // Busca indice de cup i, si no existe retorna -1
    private int indexOfCup(int i)
    {
        for (int k = 0; k < types.size(); k++)
        {
            if (types.get(k).equals("cup") && nums.get(k) == i)
            {
                return k;
            }
        }
        return -1;
    }

    // Busca indice de lid i, si no existe retorna -1
    private int indexOfLid(int i)
    {
        for (int k = 0; k < types.size(); k++)
        {
            if (types.get(k).equals("lid") && nums.get(k) == i)
            {
                return k;
            }
        }
        return -1;
    }

    // true si en cupIdx esta cup i y en cupIdx+1 esta lid i
    private boolean isCupLiddedAt(int cupIdx)
    {
        if (cupIdx < 0 || cupIdx >= types.size() - 1) return false;

        if (!types.get(cupIdx).equals("cup")) return false;

        int i = nums.get(cupIdx);

        return types.get(cupIdx + 1).equals("lid") && nums.get(cupIdx + 1) == i;
    }

    // Si existen cup i y lid i, pone lid justo encima de cup i
    private void normalizePair(int i)
    {
        int cupIdx = indexOfCup(i);
        int lidIdx = indexOfLid(i);

        if (cupIdx == -1 || lidIdx == -1) return;

        // si ya esta encima, ok
        if (lidIdx == cupIdx + 1) return;

        // guardar lid
        String lidType = types.get(lidIdx);
        int lidNum = nums.get(lidIdx);

        // quitar lid de su posicion
        types.remove(lidIdx);
        nums.remove(lidIdx);

        // si lid estaba antes que cup, cup se corrio un lugar
        if (lidIdx < cupIdx) cupIdx = cupIdx - 1;

        // insertar lid encima de cup
        types.add(cupIdx + 1, lidType);
        nums.add(cupIdx + 1, lidNum);
    }

    // =========================
    // Manage cup (3)
    // =========================

    public void pushCup(int i)
    {
        // no duplicados
        if (indexOfCup(i) != -1)
        {
            ok = false;
            showIfVisible("No se puede: ya existe la taza " + i);
            return;
        }

        // verificar espacio
        if (currentHeight() + cupHeight(i) > maxHeight)
        {
            ok = false;
            showIfVisible("No se puede: la taza " + i + " no cabe");
            return;
        }

        // agregar arriba
        types.add("cup");
        nums.add(i);

        // si ya habia tapa i, ponerla encima
        normalizePair(i);

        ok = true;
    }

    public void popCup()
    {
        if (types.isEmpty())
        {
            ok = false;
            showIfVisible("No se puede: torre vacia");
            return;
        }

        int topIdx = types.size() - 1;

        // si arriba hay lid, podria ser pareja
        if (types.get(topIdx).equals("lid"))
        {
            if (types.size() >= 2)
            {
                int belowIdx = topIdx - 1;

                // si debajo hay cup mismo numero => quitar ambos
                if (types.get(belowIdx).equals("cup") && nums.get(belowIdx).equals(nums.get(topIdx)))
                {
                    types.remove(topIdx);
                    nums.remove(topIdx);

                    types.remove(belowIdx);
                    nums.remove(belowIdx);

                    ok = true;
                    return;
                }
            }

            ok = false;
            showIfVisible("No se puede: arriba hay una tapa, no una taza");
            return;
        }

        // arriba es cup => quitarla
        types.remove(topIdx);
        nums.remove(topIdx);
        ok = true;
    }

    public void removeCup(int i)
    {
        int cupIdx = indexOfCup(i);

        if (cupIdx == -1)
        {
            ok = false;
            showIfVisible("No se puede: no existe la taza " + i);
            return;
        }

        // si esta tapada, primero quitar la lid (cupIdx+1)
        if (isCupLiddedAt(cupIdx))
        {
            types.remove(cupIdx + 1);
            nums.remove(cupIdx + 1);
        }

        // quitar cup
        types.remove(cupIdx);
        nums.remove(cupIdx);

        ok = true;
    }

    // =========================
    // Manage lid (3)
    // =========================

    public void pushLid(int i)
    {
        // no duplicados
        if (indexOfLid(i) != -1)
        {
            ok = false;
            showIfVisible("No se puede: ya existe la tapa " + i);
            return;
        }

        // verificar espacio (lid=1)
        if (currentHeight() + lidHeight() > maxHeight)
        {
            ok = false;
            showIfVisible("No se puede: la tapa " + i + " no cabe");
            return;
        }

        int cupIdx = indexOfCup(i);

        if (cupIdx != -1)
        {
            // insertar encima de su cup
            types.add(cupIdx + 1, "lid");
            nums.add(cupIdx + 1, i);
        }
        else
        {
            // si no hay cup, va arriba sola
            types.add("lid");
            nums.add(i);
        }

        ok = true;
    }

    public void popLid()
    {
        if (types.isEmpty())
        {
            ok = false;
            showIfVisible("No se puede: torre vacia");
            return;
        }

        int topIdx = types.size() - 1;

        if (!types.get(topIdx).equals("lid"))
        {
            ok = false;
            showIfVisible("No se puede: arriba no hay tapa");
            return;
        }

        types.remove(topIdx);
        nums.remove(topIdx);
        ok = true;
    }

    public void removeLid(int i)
    {
        int lidIdx = indexOfLid(i);

        if (lidIdx == -1)
        {
            ok = false;
            showIfVisible("No se puede: no existe la tapa " + i);
            return;
        }

        types.remove(lidIdx);
        nums.remove(lidIdx);
        ok = true;
    }

    // =========================
    // Reorganize tower (2)
    // =========================

    public void orderTower()
    {
        // construir indices para ordenar
        ArrayList<Integer> idx = new ArrayList<Integer>();
        for (int k = 0; k < types.size(); k++) idx.add(k);

        // ordenar indices por numero DESC, y si empatan: cup antes que lid
        Collections.sort(idx, new Comparator<Integer>() {
            public int compare(Integer ia, Integer ib)
            {
                int a = ia.intValue();
                int b = ib.intValue();

                int na = nums.get(a);
                int nb = nums.get(b);

                if (na != nb) return nb - na;

                // mismo numero: cup primero
                String ta = types.get(a);
                String tb = types.get(b);

                if (ta.equals(tb)) return 0;
                if (ta.equals("cup")) return -1;
                return 1;
            }
        });

        // reconstruir listas ordenadas
        ArrayList<String> newTypes = new ArrayList<String>();
        ArrayList<Integer> newNums = new ArrayList<Integer>();

        for (int k = 0; k < idx.size(); k++)
        {
            int old = idx.get(k);
            newTypes.add(types.get(old));
            newNums.add(nums.get(old));
        }

        types = newTypes;
        nums = newNums;

        // normalizar parejas (lid encima de cup)
        for (int k = 0; k < nums.size(); k++)
        {
            normalizePair(nums.get(k));
        }

        // recortar si no cabe
        while (currentHeight() > maxHeight && !types.isEmpty())
        {
            int last = types.size() - 1;
            types.remove(last);
            nums.remove(last);
        }

        ok = true;
    }

    public void reverseTower()
    {
        Collections.reverse(types);
        Collections.reverse(nums);

        // normalizar parejas
        for (int k = 0; k < nums.size(); k++)
        {
            normalizePair(nums.get(k));
        }

        // recortar si no cabe
        while (currentHeight() > maxHeight && !types.isEmpty())
        {
            int last = types.size() - 1;
            types.remove(last);
            nums.remove(last);
        }

        ok = true;
    }

    // =========================
    // Consult information (3)
    // =========================

    public int height()
    {
        return currentHeight();
    }

    public int[] lidedCups()
    {
        ArrayList<Integer> result = new ArrayList<Integer>();

        for (int k = 0; k < types.size() - 1; k++)
        {
            if (types.get(k).equals("cup") && isCupLiddedAt(k))
            {
                result.add(nums.get(k));
            }
        }

        int[] arr = new int[result.size()];
        for (int k = 0; k < result.size(); k++) arr[k] = result.get(k);
        return arr;
    }

    public String[][] stackingItems()
    {
        String[][] info = new String[types.size()][2];

        for (int k = 0; k < types.size(); k++)
        {
            info[k][0] = types.get(k);
            info[k][1] = "" + nums.get(k);
        }

        return info;
    }
    
    //Metodo del ciclo 2 que funciona para Tapar las tazas sin tapar la cima
    public void cover()
    {
        for (int k = 0; k < nums.size(); k++)
        {
            if (types.get(k).equals("cup"))
            {
                normalizePair(nums.get(k));
            }
        }
        ok = true;
    }
    
    
    // =========================
    // Visibility (2)
    // =========================

    public void makeVisible()
    {
        visible = true;
        ok = true;
    }

    public void makeInvisible()
    {
        visible = false;
        ok = true;
    }

    // =========================
    // Exit (1)
    // =========================

    public void exit()
    {
        types.clear();
        nums.clear();
        ok = true;
    }

    // =========================
    // ok()
    // =========================

    public boolean ok()
    {
        return ok;
    }
}